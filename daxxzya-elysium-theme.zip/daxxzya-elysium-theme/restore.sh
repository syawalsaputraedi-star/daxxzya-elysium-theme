#!/usr/bin/env bash
set -euo pipefail
BACKUP="${1:-}"

if [[ -z "$BACKUP" || ! -d "$BACKUP" ]]; then
  echo "Gunakan: sudo bash restore.sh /root/daxxzya-elysium-backup-YYYYMMDD-HHMMSS"
  exit 1
fi

echo "Backup ditemukan: $BACKUP"
echo "Restore otomatis hanya dilakukan untuk folder assets jika tersedia."

if [[ -d "$BACKUP/assets" ]]; then
  PANEL_DIR="/var/www/pterodactyl"
  if [[ -d "$PANEL_DIR/public" ]]; then
    rm -rf "$PANEL_DIR/public/assets"
    cp -a "$BACKUP/assets" "$PANEL_DIR/public/assets"
    echo "[OK] Assets restored."
  fi
fi

echo "Jika installer sebelumnya mengubah entry file, restore file .bak dari folder backup secara manual."
