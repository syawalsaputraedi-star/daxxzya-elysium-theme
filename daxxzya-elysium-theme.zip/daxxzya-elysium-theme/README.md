# Daxxzya Elysium Theme

Tema bergaya Elysium berdasarkan referensi tampilan yang diberikan:
- Dark navy / purple UI
- Card rounded
- Cosmic / galaxy accents
- Tombol hijau modern
- Branding Sano -> Daxxzya
- Footer: Daxxzya Official
- Login, account, server-list, API dan SSH page mendapat gaya yang konsisten

## Penting
Paket ini adalah theme override untuk panel berbasis Pterodactyl/Elysium. Karena setiap build Elysium bisa memiliki struktur file berbeda, `install.sh` membuat backup sebelum melakukan perubahan.

### Instalasi
1. Upload ZIP ke VPS.
2. Extract:
   `unzip daxxzya-elysium-theme.zip`
3. Masuk folder:
   `cd daxxzya-elysium-theme`
4. Jalankan:
   `sudo bash install.sh`

Default target:
`/var/www/pterodactyl`

Jika lokasi panel berbeda:
`sudo bash install.sh /path/ke/panel`

Setelah selesai, clear cache browser dan reload panel.

## Uninstall / restore
Installer membuat backup otomatis di:
`/root/daxxzya-elysium-backup-YYYYMMDD-HHMMSS`

Jangan hapus backup sampai tampilan sudah dipastikan normal.
