/*
 * DAXXZYA ELYSIUM BRANDING OVERRIDE
 * Replaces visible Sano branding without touching user data.
 */
(() => {
  const replacements = new Map([
    ["Sano Official®", "Daxxzya Official®"],
    ["Sano Official", "Daxxzya Official"],
    ["Sano", "Daxxzya"]
  ]);

  function replaceText(node) {
    if (!node || node.nodeType !== Node.TEXT_NODE) return;
    let value = node.nodeValue;
    let changed = false;
    for (const [from, to] of replacements) {
      if (value.includes(from)) {
        value = value.split(from).join(to);
        changed = true;
      }
    }
    if (changed) node.nodeValue = value;
  }

  function scan(root) {
    const walker = document.createTreeWalker(
      root,
      NodeFilter.SHOW_TEXT
    );
    const nodes = [];
    let n;
    while ((n = walker.nextNode())) nodes.push(n);
    nodes.forEach(replaceText);
  }

  function init() {
    scan(document.body);

    const observer = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        mutation.addedNodes.forEach((node) => {
          if (node.nodeType === Node.TEXT_NODE) replaceText(node);
          else if (node.nodeType === Node.ELEMENT_NODE) scan(node);
        });
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true
    });

    document.documentElement.dataset.daxxzyaElysium = "true";
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init, { once: true });
  } else {
    init();
  }
})();
